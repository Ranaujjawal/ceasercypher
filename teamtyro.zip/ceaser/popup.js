document.getElementById("decrypt").addEventListener("click", () => {
    const ciphertext = document.getElementById("ciphertext").value;
    const resultsDiv = document.getElementById("results");
    resultsDiv.innerHTML = "";

    if (!ciphertext) {
        resultsDiv.innerHTML = "<p>Please enter some text to decrypt.</p>";
        return;
    }

    const possibleDecryptions = decryptWithFrequencyAnalysis(ciphertext);

    for (const { shift, text, score } of possibleDecryptions) {
        const result = document.createElement("p");
        result.textContent = `Shift ${shift}: ${text} (Score: ${score.toFixed(2)})`;
        resultsDiv.appendChild(result);
    }
});

function caesarDecrypt(ciphertext, shift) {
    const alphabet = "abcdefghijklmnopqrstuvwxyz";
    let decryptedText = "";

    for (let char of ciphertext.toLowerCase()) {
        if (alphabet.includes(char)) {
            const newIndex = (alphabet.indexOf(char) - shift + 26) % 26;
            decryptedText += alphabet[newIndex];
        } else {
            decryptedText += char;
        }
    }

    return decryptedText;
}

function decryptWithFrequencyAnalysis(ciphertext) {
    const ENGLISH_FREQUENCIES = {
        e: 12.70, t: 9.06, a: 8.17, o: 7.51, i: 6.97,
        n: 6.75, s: 6.33, h: 6.09, r: 5.99, d: 4.25,
        l: 4.03, c: 2.78, u: 2.76, m: 2.41, w: 2.36,
        f: 2.23, g: 2.02, y: 1.97, p: 1.93, b: 1.29,
        v: 0.98, k: 0.77, j: 0.15, x: 0.15, q: 0.10, z: 0.07,
    };

    const calculateFrequencyScore = (text) => {
        const letterCounts = {};
        const totalLetters = text.split("").filter((char) => /[a-z]/.test(char)).length;

        for (let char of text.toLowerCase()) {
            if (/[a-z]/.test(char)) {
                letterCounts[char] = (letterCounts[char] || 0) + 1;
            }
        }

        let score = 0;
        for (let letter in letterCounts) {
            const actualFreq = (letterCounts[letter] / totalLetters) * 100;
            const expectedFreq = ENGLISH_FREQUENCIES[letter] || 0;
            score += Math.abs(expectedFreq - actualFreq);
        }

        return score;
    };

    const possibleDecryptions = [];
    for (let shift = 0; shift < 26; shift++) {
        const decryptedText = caesarDecrypt(ciphertext, shift);
        const score = calculateFrequencyScore(decryptedText);
        possibleDecryptions.push({ shift, text: decryptedText, score });
    }

   
    possibleDecryptions.sort((a, b) => a.score - b.score);

    return possibleDecryptions;
}


    document.getElementById("close-button").addEventListener("click", () => {
        window.close();
    });

